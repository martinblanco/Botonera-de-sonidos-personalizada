# NO BORRAR ESTE ARCHIVO

En este directorio se encuentran imagenes y copias de images usadas en la caja de sonido.

Este archivo facilita el localizar este directorio en el equipo.
