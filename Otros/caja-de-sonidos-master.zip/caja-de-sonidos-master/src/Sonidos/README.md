# NO BORRAR ESTE ARCHIVO

En este directorio se encuentran sonidos y copias de sonidos usados en la caja de sonido.

Este archivo facilita el localizar este directorio en el equipo.
